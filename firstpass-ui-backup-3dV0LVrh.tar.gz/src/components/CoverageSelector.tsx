import type { CoverageMode } from '../types/qbank'
import { label } from '../lib/ui'

interface Props {
  value: CoverageMode
  onChange: (mode: CoverageMode) => void
  total: number
  concepts: number
  filtered?: boolean
}

export default function CoverageSelector({ value, onChange, total, concepts, filtered = false }: Props) {
  return (
    <section>
      <p className={`${label} mb-2`}>Question coverage</p>
      <div className="mb-2 font-mono text-xs tabular-nums text-muted">
        {total.toLocaleString()} Total Qs · {concepts.toLocaleString()} Unique Concepts
      </div>
      <div role="group" aria-label="Question coverage" className="grid grid-cols-2 gap-1 rounded-lg border border-line bg-sunken p-1">
        <button
          type="button"
          aria-pressed={value === 'core_concepts'}
          onClick={() => onChange('core_concepts')}
          className={`rounded-md px-3 py-3 text-left transition-colors ${
            value === 'core_concepts' ? 'bg-surface text-ink shadow-sm ring-1 ring-accent/30' : 'text-muted hover:bg-surface/60'
          }`}
        >
          <span className="block text-[13px] font-semibold leading-snug sm:text-sm">
            Complete Coverage ({concepts.toLocaleString()} Qs)
          </span>
          <span className="mt-1 block text-[11px] leading-relaxed text-muted">
            {filtered ? '1 question per concept · Covers all matching concepts' : '1 question per concept · Covers 100% of indexed First Aid topics'}
          </span>
        </button>
        <button
          type="button"
          aria-pressed={value === 'all'}
          onClick={() => onChange('all')}
          className={`rounded-md px-3 py-3 text-left transition-colors ${
            value === 'all' ? 'bg-surface text-ink shadow-sm ring-1 ring-accent/30' : 'text-muted hover:bg-surface/60'
          }`}
        >
          <span className="block text-[13px] font-semibold leading-snug sm:text-sm">
            Full Bank ({total.toLocaleString()} Qs)
          </span>
          <span className="mt-1 block text-[11px] leading-relaxed text-muted">All multi-angle vignettes &amp; deep drills</span>
        </button>
      </div>
    </section>
  )
}
