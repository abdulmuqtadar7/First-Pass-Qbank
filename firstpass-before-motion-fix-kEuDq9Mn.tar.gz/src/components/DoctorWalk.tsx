import { motion, useReducedMotion } from 'motion/react'
import maleA from '../assets/doctor-male-a.png'
import maleB from '../assets/doctor-male-b.png'
import femaleA from '../assets/doctor-female-a.png'
import femaleB from '../assets/doctor-female-b.png'

export type DoctorAvatar = 'male' | 'female'

export const AVATAR_KEY = 'ui_doctor_avatar'

export function readAvatar(): DoctorAvatar | null {
  try {
    const saved = localStorage.getItem(AVATAR_KEY)
    return saved === 'male' || saved === 'female' ? saved : null
  } catch { return null }
}

export function DoctorWalk({ avatar, className = '', small = false }: {
  avatar: DoctorAvatar
  className?: string
  small?: boolean
}) {
  const reduceMotion = useReducedMotion()
  const a = avatar === 'male' ? maleA : femaleA
  const b = avatar === 'male' ? maleB : femaleB

  return (
    <motion.div
      className={`doctor-walker relative isolate select-none ${className}`}
      aria-label={`Illustration of a ${avatar} doctor walking in a white coat`}
      role="img"
      animate={reduceMotion ? undefined : { x: [-7, 7, -7], y: [0, -5, 0] }}
      transition={{ duration: 2.2, ease: 'easeInOut', repeat: Infinity }}
    >
      <img src={a} draggable={false} alt="" decoding="async" fetchPriority={small ? 'auto' : 'high'} className={`pointer-events-none absolute inset-0 h-full w-full object-contain object-bottom ${avatar === 'female' ? 'doctor-female-pose-a' : ''}`} />
      {!reduceMotion && !small && (
        <motion.img
          src={b}
          draggable={false}
          alt=""
          decoding="async"
          className="pointer-events-none absolute inset-0 h-full w-full object-contain object-bottom"
          animate={{ opacity: [0, 0, .95, .95, 0] }}
          transition={{ duration: 1.05, ease: 'easeInOut', repeat: Infinity, times: [0, .43, .5, .92, 1] }}
        />
      )}
    </motion.div>
  )
}

