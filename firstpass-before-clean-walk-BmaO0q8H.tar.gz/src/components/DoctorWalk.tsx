import { motion, useReducedMotion } from 'motion/react'
import maleA from '../assets/doctor-male-a.png'
import maleB from '../assets/doctor-male-b.png'
import femaleA from '../assets/doctor-female-a.png'
import femaleB from '../assets/doctor-female-b.png'

export type DoctorAvatar = 'male' | 'female'

export const AVATAR_KEY = 'ui_doctor_avatar'

export function readAvatar(): DoctorAvatar | null {
  try {
    const saved = localStorage.getItem(AVATAR_KEY)
    return saved === 'male' || saved === 'female' ? saved : null
  } catch { return null }
}

export function DoctorWalk({ avatar, className = '', small = false }: {
  avatar: DoctorAvatar
  className?: string
  small?: boolean
}) {
  const reduceMotion = useReducedMotion()
  const a = avatar === 'male' ? maleA : femaleA
  const b = avatar === 'male' ? maleB : femaleB
  const poseClass = avatar === 'female' && !small ? 'doctor-female-pose-a' : ''
  // Both PNGs are matching character renders at DIFFERENT points of a walking
  // gait: wide stride, then the passing/knee-up position. The pose swap is
  // essential; simply translating one still image only looks like floating.
  const move = {
    x: small ? [0, 7, 0] : ['-7%', '7%', '-7%'],
    y: [0, -3, 0, -3, 0],
    rotate: [0, 0.7, 0, -0.7, 0],
  }

  return (
    <motion.div
      // IMPORTANT: do not add `relative` here. Both the picker and the hero
      // place this element with `absolute`; conflicting positioning utilities
      // left the doctor in normal flow, cropping heads and floating above base.
      className={`doctor-walker isolate pointer-events-none select-none ${small ? 'doctor-walker-small' : ''} ${className}`}
      aria-label={`Illustration of a ${avatar} doctor walking in a white coat`}
      role="img"
      animate={reduceMotion ? undefined : move}
      transition={{ duration: small ? 3.4 : 5.4, ease: 'easeInOut', repeat: Infinity }}
    >
      <img src={a} draggable={false} alt="" decoding="async" fetchPriority={small ? 'auto' : 'high'} className={`pointer-events-none absolute inset-0 h-full w-full object-contain object-bottom ${poseClass}`} />
      {!reduceMotion && (
        <motion.img
          src={b}
          draggable={false}
          alt=""
          decoding="async"
          className={`pointer-events-none absolute inset-0 h-full w-full object-contain object-bottom ${poseClass}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0, 1, 1, 0] }}
          transition={{ duration: small ? 1.25 : 1.4, ease: 'linear', repeat: Infinity, times: [0, .44, .5, .94, 1] }}
        />
      )}
    </motion.div>
  )
}

