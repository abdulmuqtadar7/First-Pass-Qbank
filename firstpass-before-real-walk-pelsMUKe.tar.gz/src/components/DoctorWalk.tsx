import { motion, useReducedMotion } from 'motion/react'
import maleA from '../assets/doctor-male-a.png'
import maleB from '../assets/doctor-male-b.png'
import femaleA from '../assets/doctor-female-a.png'
import femaleB from '../assets/doctor-female-b.png'

export type DoctorAvatar = 'male' | 'female'

export const AVATAR_KEY = 'ui_doctor_avatar'

export function readAvatar(): DoctorAvatar | null {
  try {
    const saved = localStorage.getItem(AVATAR_KEY)
    return saved === 'male' || saved === 'female' ? saved : null
  } catch { return null }
}

export function DoctorWalk({ avatar, className = '', small = false }: {
  avatar: DoctorAvatar
  className?: string
  small?: boolean
}) {
  const reduceMotion = useReducedMotion()
  const a = avatar === 'male' ? maleA : femaleA
  const b = avatar === 'male' ? maleB : femaleB
  const move = small
    ? { y: [0, -8, 0], rotate: [-1, 1, -1] }
    : { x: ['-9%', '9%', '-9%'], y: [1, -7, 1, -7, 1], rotate: [-1, 1, -1] }

  return (
    <motion.div
      className={`doctor-walker relative isolate select-none ${small ? 'doctor-walker-small' : ''} ${className}`}
      aria-label={`Illustration of a ${avatar} doctor walking in a white coat`}
      role="img"
      animate={reduceMotion ? undefined : move}
      transition={{ duration: small ? 2 : 5.2, ease: 'easeInOut', repeat: Infinity }}
    >
      <img src={a} draggable={false} alt="" decoding="async" fetchPriority={small ? 'auto' : 'high'} className={`pointer-events-none absolute inset-0 h-full w-full object-contain object-bottom ${avatar === 'female' && !small ? 'doctor-female-pose-a' : ''}`} />
      {!reduceMotion && !small && (
        <motion.img
          src={b}
          draggable={false}
          alt=""
          decoding="async"
          className="pointer-events-none absolute inset-0 h-full w-full object-contain object-bottom"
          animate={{ opacity: [0, 0, 1, 1, 0] }}
          transition={{ duration: .86, ease: 'linear', repeat: Infinity, times: [0, .38, .45, .88, 1] }}
        />
      )}
    </motion.div>
  )
}

